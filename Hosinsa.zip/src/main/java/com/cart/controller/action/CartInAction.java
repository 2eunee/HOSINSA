package com.cart.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hosinsa.controller.HosinsaAction;
import com.hosinsa.dao.CartDAO;
import com.hosinsa.dto.CartVO;


public class CartInAction implements HosinsaAction {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pronum=request.getParameter("pronum");
		String id=request.getParameter("id");
		String quantity=request.getParameter("quantity");
		
		CartVO vo=new CartVO();
		vo.setPronum(Integer.parseInt(pronum));
		vo.setId(id);
		vo.setQuantity(Integer.parseInt(quantity));
		
		CartDAO dao=CartDAO.getInstance();
		dao.addToCart(vo);
		
		
		
	}

}
