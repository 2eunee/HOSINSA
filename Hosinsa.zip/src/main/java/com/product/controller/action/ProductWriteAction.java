package com.product.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hosinsa.controller.HosinsaAction;
import com.hosinsa.dao.ProductDAO;
import com.hosinsa.dto.ProductVO;

public class ProductWriteAction implements HosinsaAction{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductVO pVo = new ProductVO();

		pVo.setCategory(request.getParameter("category"));
		pVo.setProname(request.getParameter("proname"));
		pVo.setProimgSmall(request.getParameter("category")+"\\small_"+request.getParameter("proimg"));
		pVo.setProimgBig(request.getParameter("category")+"\\big_"+request.getParameter("proimg"));
		pVo.setBrand(request.getParameter("brand"));
		pVo.setPronum(Integer.parseInt(request.getParameter("pronum")));
		pVo.setPrice(Integer.parseInt(request.getParameter("price")));
		pVo.setStock(Integer.parseInt(request.getParameter("stock")));

		ProductDAO pDao = ProductDAO.getInstance();
		pDao.insertProduct(pVo);
		new ProductManageAction().execute(request, response);
	}
}
